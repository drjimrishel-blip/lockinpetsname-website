# LockInPetsName website preview

Upload `index.html` to the root of your GitHub repository. On Vercel select Framework Preset **Other** and Root Directory **./**. This is a static demonstration website, not a production commerce application. Breed photographs load from third-party sources and may be unavailable. Do not accept payments or claim to reserve social-media handles.
